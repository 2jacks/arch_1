export const apiUrl = 'http://localhost:3001'
